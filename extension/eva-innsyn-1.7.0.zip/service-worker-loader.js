import './assets/index.ts-UF6SSYEe.js';
